/*function youtube() {
  let URL = 'https://www.youtube.com/';
  let urlToInject = window.location.origin + __uv$config.prefix + __uv$config.encodeUrl(URL);
  const newWindow = window.open();
  const iframe = newWindow.document.createElement('iframe');
  newWindow.document.body.style.margin = '0';
  iframe.style.width = '100%';
  iframe.style.height = '100%';
  iframe.style.position = 'fixed';
  iframe.style.top = '0';
  iframe.style.left = '0';
  iframe.style.zIndex = '99999';
  iframe.style.border = 'none';
  newWindow.document.body.style.overflow = 'hidden';
  newWindow.document.body.appendChild(iframe);
  iframe.src = urlToInject;
}*/


/*apps*/
function chatGPT() {
  agU = Ultraviolet.codec.xor.encode('https://chat.shuttle.rip');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function chess() {
  agU = Ultraviolet.codec.xor.encode('https://chess.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function discord() {
  agU = Ultraviolet.codec.xor.encode('https://discord.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function github() {
  agU = Ultraviolet.codec.xor.encode('https://github.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function ng() {
  agU = Ultraviolet.codec.xor.encode('https://now.gg/play/roblox-corporation/5349/roblox');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function pin() {
  agU = Ultraviolet.codec.xor.encode('https://pinterest.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function reddit() {
  agU = Ultraviolet.codec.xor.encode('https://reddit.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function spotify() {
  agU = Ultraviolet.codec.xor.encode('https://spotify.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function tt() {
  agU = Ultraviolet.codec.xor.encode('https://tiktok.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function yt() {
  agU = Ultraviolet.codec.xor.encode('https://youtube.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function y8() {
  agU = Ultraviolet.codec.xor.encode('https://y8.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}

/*games*/
function onevone() {
  agU = Ultraviolet.codec.xor.encode('https://1v1.lol');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function brebound() {
  agU = Ultraviolet.codec.xor.encode('https://trinculo54.github.io/Boxel-rebound-hope/Newer/index.html');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function cmg() {
  agU = Ultraviolet.codec.xor.encode('https://coolmathgames.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function crazygms() {
  agU = Ultraviolet.codec.xor.encode('https://crazygames.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function geforce() {
  agU = Ultraviolet.codec.xor.encode('https://play.geforcenow.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function holeio() {
  agU = Ultraviolet.codec.xor.encode('https://hole-io.com');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function jstris() {
  agU = Ultraviolet.codec.xor.encode('https://jstris.jezevec10.com/');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function p2048() {
  agU = Ultraviolet.codec.xor.encode('https://filipekiss.github.io/2048');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function rbx() {
  agU = Ultraviolet.codec.xor.encode('https://nowgg.nl/play/roblox-corporation/5349/roblox');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function slope() {
  agU = Ultraviolet.codec.xor.encode('https://derpmandev.github.io/unblocked-games/slope');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function subway() {
  agU = Ultraviolet.codec.xor.encode('https://raw.githack.com/3kh0/3kh0-assets/main/subway-surfers/index.html');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function florr() {
  agU = Ultraviolet.codec.xor.encode('https://florr.io');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function cookieClicker() {
  agU = Ultraviolet.codec.xor.encode('https://orteil.dashnet.org/cookieclicker');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}
function rBowl() {
  agU = Ultraviolet.codec.xor.encode('https://retro-bowl.net/main.html');
  sessionStorage.setItem('agUrl', agU);
  location.href = '/lessons';
}z
